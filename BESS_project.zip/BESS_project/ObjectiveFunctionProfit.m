function revenue = ObjectiveFunctionProfit(popu, BESS_cap, P_pv, P_wind, EP)
Pd    = popu(:,1);
Pc    = popu(:,2);
RSRd  = popu(:,3);
RSRc  = popu(:,4);
RNSRd = popu(:,5);
csr = 2.25; cnsr = 2.25;


C1 = -Pc .* EP;
C2 = Pd .* EP;
C3 = (RSRd + RSRc) * csr;
C4 = RNSRd * cnsr;
delta = 1;

revenue = delta*(C1 + C2 + C3 + C4);


end