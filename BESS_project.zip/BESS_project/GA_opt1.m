function [best_pop, Profit] = GA_opt1(popu,BESS_cap, popSize, P_pv, P_wind, EP)
    Np = popSize;
    nVar = 5;
    maxGen = 100;
    pcross = 0.8;
    pmut = 0.05;
    
    %% Create initial population
  
    Lb = [0, -2, 0, -0.75, 0];
    Ub = [2, 0, 0.5, 0, 2];

    fitness = zeros(Np, 1);
    

    fitness = -ObjectiveFunctionProfit(popu, BESS_cap, P_pv, P_wind, EP);
    [bestProfit, idx] = min(fitness);
    bestSol = popu(idx, :);

    for gen = 1:maxGen
        fitness = max(fitness, 0);
        if sum(fitness) == 0
            fitness = ones(Np, 1);
        end
        cumProb = cumsum(fitness / sum(fitness));
        parents = zeros(Np, nVar);
        for i = 1:Np
            r = rand;
            selIdx = find(cumProb >= r, 1, 'first');
            parents(i, :) = popu(selIdx, :);
        end

        offspring = parents;
        for i = 1:2:Np-1
            if rand < pcross
                cp = randi([1 nVar-1]);
                offspring([i i+1], :) = [ ...
                    [parents(i, 1:cp), parents(i+1, cp+1:end)]; ...
                    [parents(i+1, 1:cp), parents(i, cp+1:end)] ];
            end
        end

        for i = 1:Np
            for j = 1:nVar
                if rand < pmut
                    step = 0.10 * (Ub(j) - Lb(j)) * randn;
                    offspring(i, j) = min(max(offspring(i, j) + step, Lb(j)), Ub(j));
                end
            end
        end

        newFit = zeros(Np, 1);
        for i = 1:Np
            ind = offspring(i, :);
            if check_constraints(ind, BESS_cap, P_pv, P_wind)
                newFit(i) = ObjectiveFunctionProfit(ind, BESS_cap, P_pv, P_wind, EP);
            else
                newFit(i) = -inf;
            end
        end

        [genBest, gidx] = max(newFit);
        if genBest > bestProfit
            bestProfit = genBest;
            bestSol = offspring(gidx, :);
        end

        popu = offspring;
        fitness = newFit;
    end

    Profit = bestProfit;
    best_pop = bestSol;
end