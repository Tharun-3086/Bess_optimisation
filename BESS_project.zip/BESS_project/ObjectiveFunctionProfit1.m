function Profit = ObjectiveFunctionProfit1(popu, BESS_cap,EP)
% OBJECTIVEFUNCTIONPROFIT – vectorised profit for GA
% --------------------------------------------------
%   P         (Np×5) – [Pd Pc RSRd RSRc RNSRd]
%   BESS_cap  scalar – battery capacity (kWh)
%
%   Replace the coefficients below with your real economic model.
% --------------------------------------------------
T=8;
Pd   = popu(:,1);
Pc   = popu(:,2);
RSRd = popu(:,3);
RSRc = popu(:,4);
RNSRd= popu(:,5);
csr = 2.25; cnsr = 2.25;
beta = 0.08;
SOCinitial = 0.02;
SOCmin =0.10;
SOCmax = 1;
eta_d = 0.90;
eta_c = 0.95;
T = 10; 
cst = 240;

C1=-Pc.*EP;
C2=Pd.*EP;
C3=(RSRd+RSRc)*csr;
C4=RNSRd*cnsr;

%constraints
constraint1 = SOCinitial - (1/eta_d) * (Pd + RNSRd) - SOCmin;

if constraint1 >= 0
   penalty = 1
   (penalty)
else
    penalty = 10000;
    (penalty)
end

constraint2 = SOCinitial + eta_c * Pc <= SOCmax;

if constraint2 > 0
   penalty = 0
   (penalty)
else
    penalty = 1000;
    (penalty)
end


fcr = (beta * (1 + beta)^T) / ((1 + beta)^T - 1);

Ccap_a = fcr * BESS_cap * cst;


COandM_a = 0.01 * BESS_cap * cst;

Cst_a = Ccap_a + COandM_a;

revenue=C1+C2+C3+C4;
expense=Cst_a;
Profit= revenue-expense;


end