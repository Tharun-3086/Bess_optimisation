function is_satisfied = check_constraints1(ind, BESS_cap, P_pv, P_wind)
Pd    = ind(1);
Pc    = ind(2);
RSRd  = ind(3);
RSRc  = ind(4);
RNSRd = ind(5);

eta_c = 0.90; eta_d = 0.90;
delta = 1;
SOC_intial = 0.5;
SOC_max = 0.95 ;
SOC_min = 0.05 ;

P_dis_max = 2;
P_ch_max = 2;

if abs(Pd) > abs(Pc)
   Ud = 1;
   Uc = 0;
else if abs(Pc) > abs(Pd)
   Ud = 0;
   Uc = 1;
else Ud = 0;
     Uc = 0;
end
end

if (Pd + RSRd > Ud * P_dis_max) || (Pc > Uc * P_ch_max) || (RSRc > Pc)
    is_satisfied = false; return;
end

SOC_new = SOC_intial + eta_c * Pc * delta *Ud - (Pd + RSRd) / eta_d * delta *Uc;
if SOC_new > SOC_max || SOC_new < SOC_min
    is_satisfied = false; return;
end

if Pc > (P_pv + P_wind)
    is_satisfied = false; return;
end

if (Pd < 0 ) && (RSRd < 0) 
    is_satisfied = false; return;
end

if RNSRd > eta_d * SOC_intial / delta
    is_satisfied = false; return;
end

if (RSRc < 0)
    is_satisfied = false; return;
end

if RNSRd > P_dis_max * (1 - Ud - Uc)
    is_satisfied = false; return;
end

is_satisfied = true;
end