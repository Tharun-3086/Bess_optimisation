clc; clear; close all;

csr = 2.25; cnsr = 2.25;
Ps = readmatrix("Find_Solarr_Power.xlsx", 'Sheet', 'Sheet1', 'Range', 'A1:A8760');
Pw = readmatrix("Final_Windd_Power.xlsx", 'Sheet', 'Sheet1', 'Range', 'A1:A8760');

%% Create hourly electricity price vector
hours_per_year = 8760;
EP_i = zeros(hours_per_year, 1);

for i = 1:hours_per_year
    hr = mod(i-1, 24) + 1;
    if ismember(hr, [1:8, 24]) || ismember(hr, 12:13)
        EP_i(i) = 0.0399;
    elseif ismember(hr, 9:11) || ismember(hr, 16:17)
        EP_i(i) = 0.1587;
    else
        EP_i(i) = 0.1317;
    end
end

%% Finding Profit using GA
BESS_list = 1:1:13;
numCases  = numel(BESS_list);
popSize   = 50;
nVar = 5;

revenue_each = zeros(8760, numCases);
best_dispatch  = zeros(numCases, 5);
popu = zeros(popSize, nVar);
profit_vector = zeros(1, numCases);

for k = 1:numCases
    BESS_cap = BESS_list(k);
    beta = 0.08; T = 10; cst = 2400;
    fcr = (beta * (1 + beta)^T) / ((1 + beta)^T - 1);
    Ccap_a = fcr * BESS_cap * cst;
    COandM_a = 0.01 * BESS_cap^2 * cst;
    Cst_a = Ccap_a + COandM_a;
    expense = Cst_a;

    for t = 1:876
        EP = EP_i(t);
        P_pv = Ps(t);
        P_wind = Pw(t);
        attempt = 0;
        i = 1;
        while i <= popSize && attempt <= 1000
            Pd = 0 + (2 - 0) * rand();
            Pc = -2 + (0 + 2) * rand();
            RSRd = Pd + (2 - Pd) * rand();
            RSRc = -Pc + (0 + Pc) * rand();
            RNSRd = 0 + (2 - 0) * rand();
            ind = [Pd Pc RSRd RSRc RNSRd];

            if check_constraints1(ind, BESS_cap, P_pv, P_wind)
                popu(i, :) = ind;
                i = i + 1;
            else
                attempt = attempt + 1;
            end
        end

        [best_pop, revenue] = GA_opt1(popu, BESS_cap, popSize, P_pv, P_wind, EP);
        revenue_each(t, k) = revenue;
        best_dispatch(k, :) = best_pop;
    end

    Revenue  = sum(revenue_each(:, k));
    Profited = Revenue - expense;
    profit_vector(k) = Profited;

    fprintf("The BESS Capacity = %d MW --> Annual Revenue = %f --> Cost = %f --> Profit = %.3f\n", ...
            BESS_cap, Revenue, expense, Profited);
end

%% Plot: Profit vs BESS Capacity
figure;
plot(BESS_list, profit_vector, 'o-', 'LineWidth', 2, 'MarkerSize', 8);
xlabel('BESS Capacity (MW)');
ylabel('Annual Profit ($)');
title('Profit vs BESS Capacity');
grid on;
