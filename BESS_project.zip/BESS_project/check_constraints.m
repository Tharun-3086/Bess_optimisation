function is_satisfied = check_constraints(ind, BESS_cap, P_pv, P_wind)
Pd    = ind(1);
Pc    = ind(2);
RSRd  = ind(3);
RSRc  = ind(4);
RNSRd = ind(5);

eta_c = 0.90; eta_d = 0.90;
delta = 1;
SOC_intial = BESS_cap/2;
SOC_max = 0.95 * BESS_cap;
SOC_min = 0.05 * BESS_cap;

P_dis_max = 2;
P_ch_max = 2;

% Discharging Constraints
if (Pd + RSRd > P_dis_max) || (Pc > P_ch_max)
    is_satisfied = false; return;
end

SOC_new = SOC_intial + eta_c * Pc * delta - (Pd + RSRd) / eta_d * delta;
if SOC_new > SOC_max || SOC_new < SOC_min
    is_satisfied = false; return;
end

if Pc > (P_pv + P_wind)
    is_satisfied = false; return;
end

if (Pd > 0 || Pc > 0) && RNSRd > 0
    is_satisfied = false; return;
end

if RNSRd > eta_d * SOC_intial / delta
    is_satisfied = false; return;
end

if Pc > 0 && Pd > 0
    is_satisfied = false; return;
end

is_satisfied = true;
end